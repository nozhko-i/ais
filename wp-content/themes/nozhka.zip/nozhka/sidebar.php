<?php
/**
 * @Packege Wordpress
 * @Subpackege Nozhka
 * @Since 1.0.0
 */
?>

<aside role="complementary">
    <?php dynamic_sidebar( 'default' ); ?>
</aside>